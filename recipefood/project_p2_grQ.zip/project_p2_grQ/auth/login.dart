import 'package:flutter/material.dart';
import '/home_page.dart';

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _login();
}

class _login extends State<login> {
  late TextEditingController _email;
  late TextEditingController _password;
  bool _validate = false;
  @override
  void initState() {
    super.initState();
    _email = TextEditingController();
    _password = TextEditingController();
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(
        //   title: Text("LOGIN"),
        //   elevation: 4,
        //   leading: GestureDetector(
        //     child: IconButton(
        //         icon: Icon(
        //           Icons.arrow_back_ios_new_outlined,
        //           size: 20,
        //           color: Colors.lightBlue,
        //         ),
        //         onPressed: () {
        //           Navigator.pop(context);
        //         }),
        //   ),
        //   leadingWidth: 100, // default is 56
        //   backgroundColor: Color.fromARGB(255, 255, 82, 82),
        //   // shape: Border(bottom: BorderSide(color: Colors.orange, width: 4)),
        // ),
        body: Stack(children: [
      Positioned(
        top: 40,
        left: 50,
        child: Container(
          child: Center(
            child: Text("LOGIN",
                style: TextStyle(
                    fontSize: 20, color: Color.fromARGB(255, 255, 255, 255))),
          ),
          width: 150.0,
          height: 50.0,
          decoration: BoxDecoration(
            color: Color.fromARGB(255, 202, 83, 15),
            borderRadius: BorderRadius.circular(60),
          ),
        ),
      ),
      Container(
          alignment: Alignment.center,
          margin: EdgeInsets.all(40),
          padding: EdgeInsets.all(30),
          child: ListView(
            children: [
              Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Email",
                    //textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 30,
                      color: Color.fromARGB(255, 255, 82, 82),
                    ),
                  )),
              TextField(
                controller: _email,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color.fromARGB(255, 184, 184, 184),
                  enabledBorder: OutlineInputBorder(),
                  errorText: _validate ? 'Value Can\'t Be Empty' : null,
                ),
              ),
              Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Password",
                    style: TextStyle(
                      fontSize: 30,
                      color: Color.fromARGB(255, 255, 82, 82),
                    ),
                  )),
              TextField(
                controller: _password,
                obscureText: true,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Color.fromARGB(255, 184, 184, 184),
                  errorText: _validate ? 'Value Can\'t Be Empty' : null,
                ),
              ),
              const SizedBox(height: 40),
              Align(
                alignment: Alignment.center,
                child: SizedBox(
                  width: 150,
                  height: 50,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          Color.fromARGB(255, 255, 177, 61), // Background color
                    ),
                    child: const Text(
                      'Next',
                      style: TextStyle(
                        fontSize: 20,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    ),
                    onPressed: () {
                      // Navigate to second route when tapped.
                      setState(() {
                        if (_email.text.isEmpty || _password.text.isEmpty) {
                          _validate = true;
                        } else {
                          _validate = false;
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const HomePage()),
                          );
                        }
                      });
                    },
                  ),
                ),
              ),
            ],
          ))
    ]));
  }
}
