import 'package:flutter/material.dart';
import 'package:recipefood/auth/login.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

const List<Widget> icons = <Widget>[
  Icon(
    Icons.girl_sharp,
    size: 40,
  ),
  Icon(
    Icons.boy_sharp,
    size: 40,
  ),
  Icon(
    Icons.group_outlined,
    size: 40,
  ),
];

class sign_up extends StatefulWidget {
  const sign_up({super.key});

  @override
  State<sign_up> createState() => _sign_up();
}

class _sign_up extends State<sign_up> {
  late TextEditingController _email;
  late TextEditingController _password;
  late TextEditingController _name;
  late TextEditingController _age;
  final List<bool> _selectedgender = <bool>[false, false, true];

  bool _validate = false;
  @override
  void initState() {
    super.initState();
    _email = TextEditingController();
    _password = TextEditingController();
    _name = TextEditingController();
    _age = TextEditingController();
  }

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    _name.dispose();
    _age.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: [
        // GestureDetector(
        //   child: IconButton(
        //       icon: Icon(
        //         Icons.arrow_back_ios_new_outlined,
        //         size: 20,
        //         color: Colors.lightBlue,
        //       ),
        //       onPressed: () {
        //         Navigator.pop(context);
        //       }),
        // ),
        Positioned(
          top: 40,
          left: 50,
          child: Container(
            child: Center(
              child: Text("SIGNUP",
                  style: TextStyle(
                      fontSize: 20, color: Color.fromARGB(255, 255, 255, 255))),
            ),
            width: 150.0,
            height: 50.0,
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 202, 83, 15),
              borderRadius: BorderRadius.circular(60),
            ),
          ),
        ),
        Container(
            margin: EdgeInsets.all(40),
            padding: EdgeInsets.all(30),
            child: ListView(
              children: [
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Name",
                      //textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 30,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                const SizedBox(height: 5),
                TextField(
                  controller: _name,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color.fromARGB(255, 184, 184, 184),
                    enabledBorder: OutlineInputBorder(),
                    errorText: _validate ? 'Value Can\'t Be Empty' : null,
                  ),
                ),
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Email",
                      //textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 30,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                const SizedBox(height: 5),
                TextField(
                  controller: _email,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color.fromARGB(255, 184, 184, 184),
                    enabledBorder: OutlineInputBorder(),
                    errorText: _validate ? 'Value Can\'t Be Empty' : null,
                  ),
                ),
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Password",
                      style: TextStyle(
                        fontSize: 30,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                const SizedBox(height: 5),
                TextField(
                  controller: _password,
                  obscureText: true,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color.fromARGB(255, 184, 184, 184),
                    errorText: _validate ? 'Value Can\'t Be Empty' : null,
                  ),
                ),
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Gender",
                      style: TextStyle(
                        fontSize: 30,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ToggleButtons(
                    onPressed: (int index) {
                      setState(() {
                        for (int i = 0; i < _selectedgender.length; i++) {
                          _selectedgender[i] = i == index;
                        }
                      });
                    },
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    selectedBorderColor: Color.fromARGB(255, 255, 82, 82),
                    selectedColor: Colors.white,
                    fillColor: Color.fromARGB(255, 255, 82, 82),
                    color: Color.fromARGB(255, 255, 82, 82),
                    isSelected: _selectedgender,
                    children: icons,
                  ),
                ),
                const SizedBox(height: 5),
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      " Female  Male  other",
                      //textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                Align(
                    alignment: Alignment.topLeft,
                    child: Text(
                      "Age",
                      style: TextStyle(
                        fontSize: 30,
                        color: Color.fromARGB(255, 255, 82, 82),
                      ),
                    )),
                const SizedBox(height: 5),
                TextField(
                  controller: _age,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: Color.fromARGB(255, 184, 184, 184),
                    errorText: _validate ? 'Value Can\'t Be Empty' : null,
                  ),
                ),
                const SizedBox(height: 40),
                Align(
                  alignment: Alignment.center,
                  child: SizedBox(
                    width: 150,
                    height: 50,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(
                            255, 255, 177, 61), // Background color
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30.0),
                        ),
                      ),
                      child: const Text(
                        'Next',
                        style: TextStyle(
                          fontSize: 20,
                          color: Color.fromARGB(255, 255, 82, 82),
                        ),
                      ),
                      onPressed: () {
                        // Navigate to second route when tapped.
                        setState(() {
                          if (_email.text.isEmpty ||
                              _password.text.isEmpty ||
                              _name.text.isEmpty ||
                              _age.text.isEmpty) {
                            _validate = true;
                          } else {
                            _validate = false;
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const login()),
                            );
                          }
                          /*   ? _validate = true
                                  : _validate = false;*/
                        });
                      },
                    ),
                  ),
                ),
              ],
            )),
      ],
    ));
  }
}

//   Future main() async {
//     // Open a connection (testdb should already exist)
//     final conn = await MySqlConnection.connect(ConnectionSettings(
//         host: 'localhost',
//         port: 3306,
//         user: 'root',
//         db: 'itds283',
//         password: '20032546'));
//     var result = await conn.query('insert into login values (?, ?, ? , ?,?)',
//         [_email, _password, _name, _selectedgender, _age]);
//     print(_email);
//     print('Inserted row id=${result.insertId}');
//   }
// }

// // var result = await conn.query(
// //     'insert into users (name, email, age) values (?, ?, ?)',
// //     ['Bob', 'bob@bob.com', 25]);
// // print('Inserted row id=${result.insertId}');

