import 'dart:convert';

List<Food> foodFromJson(String str) => List<Food>.from(json.decode(str).map((x) => Food.fromJson(x)));

String foodToJson(List<Food> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Food {
    Food({
        required this.title,
        required this.ingredients,
        required this.servings,
        required this.instructions,
    });

    String title;
    String ingredients;
    String servings;
    String instructions;

    factory Food.fromJson(Map<String, dynamic> json) => Food(
        title: json["title"],
        ingredients: json["ingredients"],
        servings: json["servings"],
        instructions: json["instructions"],
    );

    Map<String, dynamic> toJson() => {
        "title": title,
        "ingredients": ingredients,
        "servings": servings,
        "instructions": instructions,
    };
}