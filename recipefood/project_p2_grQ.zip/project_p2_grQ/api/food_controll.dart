import 'dart:convert';
import 'package:recipefood/api/foodmodel.dart';
// import 'package:food_app/food_database.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class FoodController extends GetxController {
  RxList<Food> foodModels = <Food>[].obs;
  void fetchFools() async {
    Map<String, String> requestHeaders = {
    'Content-type': 'application/json, text/json',
    'Accept-Language': 'en',
    'Authorization': 'Bearer Gu7JZpo)sYF4NyKVDxAUzZyxxueFAuxxt7Yc7YFqEOwtK0lDFkD79GsVfhC6eVndx5EYDQRvx1juOFboD2TqsgG=====2'
  }; 
    final url = await http.get(Uri.parse("http://10.62.124.44:8080/list"));
      http.Response response = await http.get(url,headers: requestHeaders);
    if (response.statusCode == 200) {
      final data = jsonDecode(response.body).cast<Map<String, dynamic>>();
      foodModels.value = data
          .map<Food>((json) => Food.fromJson(json))
          .toList(); //ได้มาเป็น List แล้ว
    } else {
      throw Exception("failed");
    }
    print(response.body);
  }
}
