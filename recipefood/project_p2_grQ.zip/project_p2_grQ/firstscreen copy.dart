import 'package:flutter/material.dart';
import 'package:recipefood/auth/login.dart';
import 'package:recipefood/auth/sign_up.dart';

class firstpage extends StatefulWidget {
  const firstpage({super.key});

  @override
  State<firstpage> createState() => _firstpage();
}

class _firstpage extends State<firstpage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned(
            bottom: 150,
            child: Container(
              child: Image(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                image: NetworkImage(
                    "https://img.freepik.com/premium-vector/cartoon-kid-cook_10308-227.jpg"),
              ),
            ),
          ),
          Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.5,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(100),
                ),
                child: Column(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.only(top: 60, left: 60, right: 60),
                      child: Column(
                        children: [
                          Text(
                            "Prung Rose",
                            style: TextStyle(
                              fontSize: 50,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 255, 82, 82),
                            ),
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color.fromARGB(
                                  255, 255, 177, 61), // Background color
                            ),
                            child: const Text(
                              'SINGUP',
                              style: TextStyle(
                                fontSize: 20,
                                color: Color.fromARGB(255, 255, 82, 82),
                              ),
                            ),
                            onPressed: () {
                              // Navigate to second route when tapped.
                              setState(() {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const sign_up()),
                                );
                              });
                            },
                          ),
                          ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color.fromARGB(
                                  255, 255, 177, 61), // Background color
                            ),
                            child: const Text(
                              'LOGIN',
                              style: TextStyle(
                                fontSize: 20,
                                color: Color.fromARGB(255, 255, 82, 82),
                              ),
                            ),
                            onPressed: () {
                              // Navigate to second route when tapped.
                              setState(() {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => const login()),
                                );
                              });
                            },
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}
