import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:recipefood/auth/sign_up.dart';

// Home Tab

class Screen1 extends StatelessWidget {
  const Screen1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _selectedColor = Color.fromARGB(255, 212, 90, 19);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _selectedColor,
        title: const Text(
          "Prung Rose",
          style: TextStyle(fontSize: 20),
        ),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        children: <Widget>[
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                child: TextField(
                  decoration: InputDecoration(
                    enabledBorder: const OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(20.0)),
                      borderSide: const BorderSide(
                        color: Colors.grey,
                      ),
                    ),
                    hintText: 'Search.... ',
                    prefixIcon: GestureDetector(
                      child: IconButton(
                          icon: Icon(
                            Icons.arrow_back_ios_new_outlined,
                            size: 30,
                            color: Color.fromARGB(255, 255, 231, 123),
                          ),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const Screen1()),
                            );
                          }),
                    ),
                    suffixIcon: Icon(Icons.search,
                        color: Color.fromARGB(255, 212, 90, 19)),
                  ),
                ),
              )
            ],
          ),
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "COOKIE",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/2ChocolateChipCookies.jpg/375px-2ChocolateChipCookies.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "PAD THAI",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Phat_Thai_kung_Chang_Khien_street_stall.jpg/330px-Phat_Thai_kung_Chang_Khien_street_stall.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "SOM TUM",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://localiseasia.com/wp-content/uploads/2022/03/som-tum_Som-Tum-Thai-770x500.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "CAKE",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://preppykitchen.com/wp-content/uploads/2022/05/Naked-Cake-Feature-768x1088.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
        ],
      ),
      // ElevatedCardExample(),
      // FilledCardExample(),
      // OutlinedCardExample(),
      //       ],
      //     ),
    );
  }
}

// /// https://m3.material.io/components/cards/specs#a012d40d-7a5c-4b07-8740-491dec79d58b
// class ElevatedCardExample extends StatelessWidget {
//   const ElevatedCardExample({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const Center(
//       child: Card(
//         child: SizedBox(
//           width: 300,
//           height: 100,
//           child: Center(child: Text('Elevated Card')),
//         ),
//       ),
//     );
//   }
// }

// /// https://m3.material.io/components/cards/specs#0f55bf62-edf2-4619-b00d-b9ed462f2c5a
// class FilledCardExample extends StatelessWidget {
//   const FilledCardExample({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Card(
//         elevation: 0,
//         color: Theme.of(context).colorScheme.surfaceVariant,
//         child: const SizedBox(
//           width: 300,
//           height: 100,
//           child: Center(child: Text('Filled Card')),
//         ),
//       ),
//     );
//   }
// }

// class OutlinedCardExample extends StatelessWidget {
//   const OutlinedCardExample({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return Center(
//       child: Card(
//         elevation: 0,
//         shape: RoundedRectangleBorder(
//           side: BorderSide(
//             color: Theme.of(context).colorScheme.outline,
//           ),
//           borderRadius: const BorderRadius.all(Radius.circular(12)),
//         ),
//         child: const SizedBox(
//           width: 300,
//           height: 100,
//           child: Center(child: Text('Outlined Card')),
//         ),
//       ),
//     );
//   }
// }
