import 'package:flutter/material.dart';
import 'package:recipefood/food/cookie.dart';

// Home Tab
class Screen4 extends StatelessWidget {
  const Screen4({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _selectedColor = Color.fromARGB(255, 212, 90, 19);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _selectedColor,
        title: const Text(
          "Prung Rose",
          style: TextStyle(fontSize: 20),
        ),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        children: <Widget>[
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const page1()),
              );
            },
            child: Container(
              color: Color.fromARGB(255, 223, 221, 221),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Align(
                      alignment: Alignment.center,
                      child: Text(
                        "COOKIE",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                  Image.network(
                    alignment: Alignment.centerRight,
                    "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/2ChocolateChipCookies.jpg/375px-2ChocolateChipCookies.jpg",
                    // height: MediaQuery.of(context).size.height,
                    // width: MediaQuery.of(context).size.width,
                    height: 150,
                    width: 150,
                  )
                ],
              ),
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "PAD THAI",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Phat_Thai_kung_Chang_Khien_street_stall.jpg/330px-Phat_Thai_kung_Chang_Khien_street_stall.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "SOM TUM",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://localiseasia.com/wp-content/uploads/2022/03/som-tum_Som-Tum-Thai-770x500.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "CAKE",
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://preppykitchen.com/wp-content/uploads/2022/05/Naked-Cake-Feature-768x1088.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
        ],
      ),
      // ElevatedCardExample(),
      // FilledCardExample(),
      // OutlinedCardExample(),
      //       ],
      //     ),
    );
  }
}
