import 'package:flutter/material.dart';

// Home Tab
class Screen2 extends StatelessWidget {
  const Screen2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _selectedColor = Color.fromARGB(255, 212, 90, 19);

    return Scaffold(
        appBar: AppBar(
          backgroundColor: _selectedColor,
          title: const Text(
            "NOTE",
            style: TextStyle(fontSize: 20),
          ),
          automaticallyImplyLeading: false,
        ),
        body: ListView(children: <Widget>[
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Icon(Icons.add),
                Container(
                  width: 200,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Ultimate Chocolate Chip Cookies",
                        style: TextStyle(
                          fontSize: 25,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://images-gmi-pmc.edge-generalmills.com/cbe8b51a-c3c1-4dcf-8d79-76f98565d3e0.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Icon(Icons.add),
                Container(
                  width: 200,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Curry-Puffs",
                        style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.bold,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://christieathome.com/wp-content/uploads/2020/12/Malaysian-Curry-Puffs-6-1-2048x2048.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
        ]));
  }
}
