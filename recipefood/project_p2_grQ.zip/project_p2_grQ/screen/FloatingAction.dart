import 'package:flutter/material.dart';
import 'package:recipefood/screen/newnote.dart';

class FloatingAction extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.end,
      children: [
        Container(
          margin: EdgeInsets.only(bottom: 40),
          child: FloatingActionButton(
            onPressed: () {
              // print('click en botton');
              Navigator.of(context).push(
                MaterialPageRoute(builder: (context) => newnote()),
              );
            },
            child: Icon(Icons.add_box_outlined),
            backgroundColor: Colors.red,
          ),
        ),
      ],
    );
  }
}
