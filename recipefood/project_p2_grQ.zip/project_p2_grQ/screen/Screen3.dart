import 'package:flutter/material.dart';

// Home Tab
class Screen3 extends StatelessWidget {
  const Screen3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _selectedColor = Color.fromARGB(255, 212, 90, 19);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: _selectedColor,
        title: const Text(
          "Q&A",
          style: TextStyle(fontSize: 20),
        ),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        children: <Widget>[
          Container(
              height: 100,
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Image.asset(height: 90, width: 60, "assets/gold.png"),
                    Container(
                      height: 50,
                      width: 250,
                      decoration: BoxDecoration(
                        color: Color.fromARGB(255, 255, 214, 52),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Align(
                          alignment: Alignment.center,
                          child: Text(
                            "Top 10 For this week",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: Color.fromARGB(255, 212, 90, 19),
                            ),
                          )),
                    ),
                  ])),
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text("1",
                    style: TextStyle(
                      fontSize: 30,
                    )),
                Container(
                  width: 220,
                  height: 50,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Where was the Hawaiian pizza invented?",
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/Eataly_Las_Vegas_-_Feb_2019_-_Sarah_Stierch_12.jpg/800px-Eataly_Las_Vegas_-_Feb_2019_-_Sarah_Stierch_12.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text("2",
                    style: TextStyle(
                      fontSize: 30,
                    )),
                Container(
                  width: 220,
                  height: 50,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "What type of pastry are profiteroles made with?",
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://images.immediate.co.uk/production/volatile/sites/30/2013/05/Puttanesca-fd5810c.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 223, 221, 221),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text("3",
                    style: TextStyle(
                      fontSize: 30,
                    )),
                Container(
                  width: 220,
                  height: 50,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Which fast food restaurant's logo features four yellow squares on a blue background?",
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://www.shutterstock.com/image-illustration/fast-food-restaurant-3d-rendering-600w-584481970.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
          Container(
            color: Color.fromARGB(255, 255, 238, 238),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text("4",
                    style: TextStyle(
                      fontSize: 30,
                    )),
                Container(
                  width: 220,
                  height: 50,
                  child: Align(
                      alignment: Alignment.center,
                      child: Text(
                        "Grenadine comes from which fruit?",
                        style: TextStyle(
                          fontSize: 15,
                          color: Color.fromARGB(255, 0, 0, 0),
                        ),
                      )),
                ),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://cdn.shopify.com/s/files/1/0234/7849/files/IMG_9685.jpg?v=1580417299",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 150,
                  width: 150,
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
