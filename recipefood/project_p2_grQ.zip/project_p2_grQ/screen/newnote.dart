import 'package:flutter/material.dart';
// import '/home_page.dart';

class newnote extends StatefulWidget {
  const newnote({super.key});

  @override
  State<newnote> createState() => _newnote();
}

class _newnote extends State<newnote> {
  @override
  // of the TextField.
  final myController = TextEditingController();
  final myController1 = TextEditingController();
  final myController2 = TextEditingController();
  final myController3 = TextEditingController();
  final myController4 = TextEditingController();

  @override
  void initState() {
    super.initState();

    // Start listening to changes.
    myController.addListener(_printLatestValue);
  }

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the widget tree.
    // This also removes the _printLatestValue listener.
    myController.dispose();
    super.dispose();
  }

  void _printLatestValue() {
    print('Second text field: ${myController.text}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          controller: myController,
        ),
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: myController1,
            ),
            TextField(
              controller: myController2,
            ),
            TextField(
              controller: myController3,
            ),
            TextField(
              controller: myController4,
            ),
          ],
        ),
      ),
    );
  }
}
