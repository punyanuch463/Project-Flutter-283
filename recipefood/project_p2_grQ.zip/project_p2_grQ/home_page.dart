import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'screen/Screen1.dart';
import 'screen/Screen2.dart';
import 'screen/Screen3.dart';
import 'screen/Screen4.dart';
import 'screen/FloatingAction.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  final _selectedColor = Color.fromARGB(255, 212, 90, 19);
  final List<Widget> _tabs = [
    const Screen4(), //homepage
    const Screen1(), //search
    const Screen2(), //note
    const Screen3() //Q&A
  ];
  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
        floatingActionButton: FloatingAction(),
        body: CupertinoTabScaffold(
          //   bottomNavigationBar: CupertinoTabScaffold(
          tabBar: CupertinoTabBar(
            activeColor: Colors.black,
            inactiveColor: Color.fromARGB(255, 250, 246, 23),
            backgroundColor: _selectedColor,
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.list_dash),
                // label: 'Favourites',
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.search),
                //  label: 'Recents',
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.news),
                //  label: 'Contacts',
              ),
              BottomNavigationBarItem(
                icon: Icon(CupertinoIcons.question_square_fill),
                //  label: 'Keypad',
              ),
            ],
          ),
          tabBuilder: (BuildContext context, int index) {
            return CupertinoTabView(
              builder: (BuildContext context) {
                return _tabs[index];
              },
            );
          },
        ));
  }
}

class FabExample extends StatelessWidget {
  const FabExample({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('FloatingActionButton Sample'),
      ),
      body: const Center(child: Text('Press the button below!')),
      // An example of the floating action button.
      //
      // https://m3.material.io/components/floating-action-button/specs
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add your onPressed code here!
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
