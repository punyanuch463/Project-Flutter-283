import 'package:flutter/material.dart';

// Home Tab
class page1 extends StatelessWidget {
  const page1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final _selectedColor = Color.fromARGB(255, 212, 90, 19);

    return Scaffold(
      appBar: AppBar(
        elevation: 4,
        leading: GestureDetector(
          child: IconButton(
              icon: Icon(
                Icons.arrow_back_ios_new_outlined,
                size: 20,
                color: Color.fromARGB(255, 255, 231, 123),
              ),
              onPressed: () {
                Navigator.pop(context);
              }),
        ),
        backgroundColor: _selectedColor,
        title: const Text(
          "making cookie",
          style: TextStyle(fontSize: 20),
        ),
        automaticallyImplyLeading: false,
      ),
      body: ListView(
        children: <Widget>[
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Align(
                    alignment: Alignment.center,
                    child: Text(
                      "COOKIE",
                      style: TextStyle(
                        fontSize: 50,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      ),
                    )),
                Image.network(
                  alignment: Alignment.centerRight,
                  "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/2ChocolateChipCookies.jpg/375px-2ChocolateChipCookies.jpg",
                  // height: MediaQuery.of(context).size.height,
                  // width: MediaQuery.of(context).size.width,
                  height: 100,
                  width: 100,
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              decoration: new BoxDecoration(
                border: new Border.all(color: Colors.yellow),
                borderRadius: BorderRadius.all(Radius.circular(20)),
                color: Colors.yellow,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    child: Text(
                      "We're big fans of chocolate chip cookies, and these are the best of the best! Our Ultimate Chocolate Chip Cookies are sure to impress cookie connoisseurs everywhere—slightly crispy on the outside and perfectly chewy on the inside, it's no wonder these cookies are top-rated by hundreds of satisfied home bakers. Whip up a batch of Ultimate Chocolate Chip Cookies to hand out to family or friends, and get ready for the compliments to roll in!",
                      style: TextStyle(fontSize: 15),
                    ),
                  ),
                  Container(
                    child: Text(
                      "Ingredients :",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  Text("2 1/4 cups Gold Medal™ all-purpose flour"),
                  Text("1 teaspoon baking soda"),
                  Text("1/2 teaspoon salt"),
                  Text("1 cup butter, softened"),
                  Text("3/4 cup granulated suga"),
                  Text("3/4 cup packed brown sugar"),
                  Text("1 egg"),
                  Text("1 teaspoon vanilla"),
                  Text("2 cups semisweet chocolate chips"),
                  Text("1 cup coarsely chopped nuts, if desired"),
                  Container(
                    child: Text(
                      "Time : ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  Text(
                      "Bake 8 to 10 minutes or until light brown (centers will be soft). Cool 2 minutes;"),
                  Container(
                    child: Text(
                      "Step  : ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  Text(
                      "1. Heat oven to 375°F. In small bowl, mix flour, baking soda and salt; set aside."),
                  Text(
                      "2. In large bowl, beat softened butter and sugars with electric mixer on medium speed, or mix with spoon about 1 minute or until fluffy, scraping side of bowl occasionally."),
                  Text(
                      "3. Beat in egg and vanilla until smooth. Stir in flour mixture just until blended (dough will be stiff). Stir in chocolate chips and nuts."),
                  Text(
                      "4. Onto ungreased cookie sheets, drop dough by rounded tablespoonfuls 2 inches apart."),
                  Text(
                      "5. Bake 8 to 10 minutes or until light brown (centers will be soft). Cool 2 minutes; remove from cookie sheet to cooling rack. Cool completely, about 30 minutes. Store covered in airtight container."),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
